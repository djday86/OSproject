/*15:*/
#line 11 "./preliminaries.w"

#ifndef _DATATYPES_H
#define _DATATYPES_H

typedef char s8;
typedef unsigned char u8;


typedef short int s16;
typedef unsigned short int u16;


typedef int s32;
typedef unsigned int u32;


typedef long long int s64;
typedef unsigned long long int u64;

#endif

#line 51 "./osProject.w"

#line 1 "./vdi.w"
/*:15*/
